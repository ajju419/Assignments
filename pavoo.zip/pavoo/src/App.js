import logo from './logo.svg';
import './App.css';


import First from './Components/First';
import Nine from './Components/Nine';
import Second from './Components/Second';
import Third from './Components/Third';


function App() {
  return (
    <div className="App">
    <Third/>
    {/* <Second/> */}
    {/* <Fifth/> */}
    {/* <First/> */}
    {/* <Fifth/> */}
    {/* <Sixth/> */}
    {/* <Seven/> */}
    {/* <Nine/> */}
    {/* <Eleven/> */}
    {/* <Twelve/> */}
    {/* <Fourteen/> */}
    {/* <Fifteen/> */}
    {/* <Sixteen/> */}
    {/* <Seventeen/> */}
    {/* <Twenty/> */}
    </div>
  );
}

export default App;