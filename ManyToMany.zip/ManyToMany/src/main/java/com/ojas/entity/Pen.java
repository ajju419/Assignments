package com.ojas.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pen {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int pid;
	
	public String pname;
	@ManyToMany( cascade=CascadeType.ALL)
	List<Student> students;

}
