package com.ojas.dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import com.ojas.entity.Pen;
import com.ojas.entity.Student;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Configuration cfg=new Configuration();
     cfg.configure();
     SessionFactory sf=cfg.buildSessionFactory();
     Session s=sf.openSession();
     Transaction tx=s.beginTransaction();
     
     Pen p=new Pen();
     p.setPname("blue");
     
     Pen p1=new Pen();
     p1.setPname("red");
     
     
     ArrayList<Pen> list=new ArrayList<Pen>();
     list.add(p);
     list.add(p1);
     
     Student stu=new Student();
     stu.setStuname("sampath");
     
     Student stu1=new Student();
     stu1.setStuname("sampath kumar");
     
     
     ArrayList<Student> list2=new ArrayList<Student>();
     list2.add(stu);
     list2.add(stu1);
     
      stu.setPen(list);
      stu1.setPen(list);
      p.setStudents(list2);
      p.setStudents(list2);
    
    s.saveOrUpdate(stu);
    s.saveOrUpdate(stu1);
    tx.commit();
    s.close();
    sf.close();
	}

}
