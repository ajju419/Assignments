package com.ojas.dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ojas.entity.Student1;
import com.ojas.entity.Subjects;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		cfg.configure();
		
		SessionFactory sf = cfg.buildSessionFactory();
		
		Session s = sf.openSession();
		
		Transaction tx = s.beginTransaction();

		Subjects sub = new Subjects();
		sub.setSname("Java");
		
		Student1 stu = new Student1();
		stu.setStuname("sam");
		stu.setSubjects("python");

		sub.setStd(stu);
		s.save(sub);

		tx.commit();
		sf.close();
		s.close();
	}

}
