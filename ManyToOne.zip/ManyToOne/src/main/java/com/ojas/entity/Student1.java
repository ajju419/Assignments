package com.ojas.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Student1 {
   
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int sid;
	
	public String stuname;
	
	public String subjects;
	
	public Student1(){}

	public Student1(String stuname, String subjects) {
		super();
		this.stuname = stuname;
		this.subjects = subjects;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getStuname() {
		return stuname;
	}

	public void setStuname(String stuname) {
		this.stuname = stuname;
	}

	public String getSubjects() {
		return subjects;
	}

	public void setSubjects(String subjects) {
		this.subjects = subjects;
	}

	@Override
	public String toString() {
		return "Student1 [sid=" + sid + ", stuname=" + stuname + ", subjects=" + subjects + "]";
	}

	
	

	
	
	
}
