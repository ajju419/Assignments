package com.ojas.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Subjects {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int sid;
	
	public String sname;
	
	public Subjects(){}
    
	public Subjects(String sname) {
		super();
		this.sname = sname;
		
	}

	@ManyToOne(cascade=CascadeType.ALL)
	public Student1 Std;

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Student1 getStd() {
		return Std;
	}

	public void setStd(Student1 std) {
		Std = std;
	}

	@Override
	public String toString() {
		return "Subjects [sid=" + sid + ", sname=" + sname + ", Std=" + Std + "]";
	}

	
   
	
	
}
