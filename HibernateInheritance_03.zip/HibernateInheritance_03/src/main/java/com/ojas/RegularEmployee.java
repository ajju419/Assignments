package com.ojas;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="REGULAR_EMPLOYEE")
public class RegularEmployee extends Employee {
	public double Salary;
	
	public int bonus;

	public double getSalary() {
		return Salary;
	}

	public void setSalary(double salary) {
		Salary = salary;
	}

	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
	
	

}
