package com.ojas;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="CONTRACT_EMPLOYEE")
public class ContractEmployee extends Employee {
	
	public String duration;
	
	public float pay_perhour;

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public float getPay_perhour() {
		return pay_perhour;
	}

	public void setPay_perhour(float pay_perhour) {
		this.pay_perhour = pay_perhour;
	}
	
	

}
