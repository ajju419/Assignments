package com.ojas;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction tx=s.beginTransaction();
		
		Employee e=new Employee();
		e.setId(1);
		e.setName("sampath");
		
		RegularEmployee e1=new RegularEmployee();
		e1.setId(2);
		e1.setName("vani");
		e1.setSalary(10000);
		e1.setBonus(10);
		
		
		ContractEmployee e2=new ContractEmployee();
		e2.setId(3);
		e2.setName("sampath kumar");
		e2.setDuration("40hrs");
		e2.setPay_perhour(1000);
		
		s.save(e);
		s.save(e1);
		s.save(e2);
		tx.commit();
		s.close();
		sf.close();
	}

}
