package com.ojas;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CreateEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction tx=s.beginTransaction();
		
		Employee e1=new Employee();
		e1.setEid(5);
		e1.setEname("vani ");
		e1.setSalary(5000);
		s.saveOrUpdate(e1);
		if(s.contains(e1)){
			System.out.println("persistent");
		}else{
			System.out.println("transient");
		}
		tx.commit();
		s.close();
		sf.close();
	}

}
