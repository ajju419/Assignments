package com.ojas.dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ojas.Entity.Answer;
import com.ojas.Entity.Questions;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction tx=s.beginTransaction();
		
		Answer a1=new Answer();
		a1.setAnswer("A");
		
		Answer a2=new Answer();
		a2.setAnswer("B");
		
		Answer a3=new Answer();
		a3.setAnswer("All the Above");
		
		ArrayList<Answer> list=new ArrayList<Answer>();
		list.add(a1);
		list.add(a2);
		list.add(a3);
		
		Questions q1=new Questions();
		q1.setQuestion("what are Alphabets");
		q1.setAnswer(list);
		s.save(q1);
		tx.commit();
		sf.close();
		s.close();
	}

}
