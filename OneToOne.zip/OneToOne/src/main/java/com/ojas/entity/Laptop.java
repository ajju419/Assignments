package com.ojas.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Laptop {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	public int lid;
	
	public String lname;
	
	public String version;
	
	@OneToOne(cascade=CascadeType.ALL)
	public Student student;
	

	public Laptop(){}
	
	
	public Laptop(int lid, String lname, String version) {
		super();
		this.lid = lid;
		this.lname = lname;
		this.version = version;
	}

	public int getLid() {
		return lid;
	}

	public void setLid(int lid) {
		this.lid = lid;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
	
	
}
