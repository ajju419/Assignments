package com.ojas.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class W {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int Wid;
	
	public String Wname;
   
	public W(){}
	

	public W(String wname) {
		super();
		Wname = wname;
	}

	public int getWid() {
		return Wid;
	}

	public void setWid(int wid) {
		Wid = wid;
	}

	public String getWname() {
		return Wname;
	}

	public void setWname(String wname) {
		Wname = wname;
	}
	
	
	
}
