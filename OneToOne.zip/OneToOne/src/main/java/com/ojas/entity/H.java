package com.ojas.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class H {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int hid;
	
	public String hname;
    
	@OneToOne(cascade=CascadeType.ALL)
	public W w;
	
	public W getW() {
		return w;
	}

	public void setW(W w) {
		this.w = w;
	}

	public H(){}
	
	public H( String hname) {
		super();
		
		this.hname = hname;
	}

	public int getHid() {
		return hid;
	}

	public void setHid(int hid) {
		this.hid = hid;
	}

	public String getHname() {
		return hname;
	}

	public void setHname(String hname) {
		this.hname = hname;
	}
	
	
	

}
