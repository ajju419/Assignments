package com.ojas.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ojas.entity.Laptop;
import com.ojas.entity.Student;

public class Store {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();

		Laptop obj1 = new Laptop();

		obj1.setLname("lenova");
		obj1.setVersion("5th");

		Laptop obj5 = new Laptop();

		obj5.setLname("dell");
		obj5.setVersion("5th");
		
		Laptop obj2 = new Laptop();
		obj1.setLname("hp");
		obj1.setVersion("5th");

		Student obj3 = new Student();
		obj3.setName("sampath");
		obj3.setLaptop(obj2);

		Student obj = new Student();
		obj.setName("sampath");
		obj.setLaptop(obj1);
		
		Student obj6 = new Student();
		obj6.setName("vani");
		obj6.setLaptop(obj5);

		// obj.setLaptop(obj1);
		// obj1.setStudent(obj);
		s.save(obj);
		s.save(obj3);
		s.save(obj6);
		tx.commit();
		sf.close();
		s.close();

	}

}
