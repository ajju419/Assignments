package com.ojas.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ojas.entity.H;
import com.ojas.entity.W;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Configuration cfg=new Configuration();
      cfg.configure("hibernate1.cfg.xml");
      SessionFactory sf=cfg.buildSessionFactory();
      Session s=sf.openSession();
      Transaction tx=s.beginTransaction();
      
      W obj1=new W();
      obj1.setWname("Anushka");
      
      H obj=new H();
      obj.setHname("virat Kohli");
      obj.setW(obj1);
     
      s.save(obj);
      tx.commit();
      sf.close();
      s.close();
      
	}

}
